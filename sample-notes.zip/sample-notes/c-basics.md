---
id: c-basics
label: C++ Basics
category: language
priority: medium
status: learning
last_quiz_score: null
next_review: null
ease_factor: 2.5
interval: 1
createdAt: 2025-01-12T10:00:00Z
updatedAt: 2025-01-12T10:00:00Z
relations:
  - target: linux
    type: compiles_on
    weight: 0.4
resources:
  - type: documentation
    title: cppreference.com
    url: https://en.cppreference.com
---

## What is C++?
C++ is a general-purpose programming language created as an extension of C, adding object-oriented, generic, and functional features.

## Key Concepts
- **Variables & Types**: `int`, `double`, `bool`, `std::string`
- **Pointers**: Memory addresses — `int* ptr = &x;`
- **References**: Aliases — `int& ref = x;`
- **Classes**: Encapsulate data and behavior
- **Templates**: Generic programming
- **RAII**: Resource Acquisition Is Initialization

## Hello World
```cpp
#include <iostream>
int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
```

## Memory Management
- Stack: automatic, fast, limited size
- Heap: `new` / `delete`, manual management
- Smart pointers: `std::unique_ptr`, `std::shared_ptr`

Note: slugify('C++ Basics') = 'c-basics' — special chars stripped.
