---
id: linux
label: Linux
category: concept
priority: medium
status: to_review
last_quiz_score: null
next_review: null
ease_factor: 2.5
interval: 1
createdAt: 2025-01-09T10:00:00Z
updatedAt: 2025-01-09T10:00:00Z
relations:
  - target: tcpip
    type: uses
    weight: 0.5
resources:
  - type: documentation
    title: Linux man pages
    url: https://man7.org/linux/man-pages/
---

## What is Linux?
Linux is a free, open-source Unix-like operating system kernel first released by Linus Torvalds in 1991. It powers servers, containers, mobile devices, and more.

## Key Concepts
- **Kernel**: Core of the OS, manages hardware resources
- **Shell**: Command-line interface (bash, zsh, sh)
- **File system**: Everything is a file — `/proc`, `/dev`, `/etc`
- **Permissions**: User/group/other read-write-execute model

## Essential Commands
- `ls -la` — list files with permissions
- `chmod 755 script.sh` — set file permissions
- `grep -r "pattern" .` — recursive text search
- `systemctl status nginx` — check service status
- `ps aux | grep process` — find running processes

## Why Learn Linux?
Almost all production servers run Linux. Required knowledge for Docker, Kubernetes, and cloud platforms.
