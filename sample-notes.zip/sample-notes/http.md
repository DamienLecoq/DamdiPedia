---
id: http
label: HTTP
category: network
priority: high
status: mastered
ease_factor: 2.9
interval: 30
createdAt: 2025-01-10T10:00:00Z
updatedAt: 2025-01-10T10:00:00Z
relations:
  - target: tcpip
    type: uses
    weight: 0.8
resources:
  - type: documentation
    title: MDN HTTP Docs
    url: https://developer.mozilla.org/en-US/docs/Web/HTTP
---

## What is HTTP?
HTTP is the application-layer protocol for web data transfer.

## Key Concepts
- **Methods**: GET POST PUT PATCH DELETE
- **Status codes**: 2xx 3xx 4xx 5xx
- **Headers**: Content-Type Authorization Cache-Control
- **HTTPS**: HTTP over TLS

## Request / Response cycle
1. Client sends HTTP request with method, headers, optional body
2. Server processes and responds with status code + body
3. Connection closed (HTTP/1.1) or kept alive (Keep-Alive / HTTP/2)
