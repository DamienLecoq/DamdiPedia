---
id: tcpip
label: TCP/IP
category: network
priority: high
status: learning
last_quiz_score: null
next_review: null
ease_factor: 2.5
interval: 1
createdAt: 2025-01-08T10:00:00Z
updatedAt: 2025-01-08T10:00:00Z
relations:
  - target: linux
    type: runs_on
    weight: 0.6
resources:
  - type: documentation
    title: RFC 793 - TCP
    url: https://www.rfc-editor.org/rfc/rfc793
---

## What is TCP/IP?
TCP/IP (Transmission Control Protocol / Internet Protocol) is the foundational protocol suite for internet communication.

## The 4 Layers
1. **Application** — HTTP, DNS, FTP, SSH
2. **Transport** — TCP (reliable) / UDP (fast, lossy)
3. **Internet** — IP addressing, routing (IPv4/IPv6)
4. **Link** — Ethernet, Wi-Fi, physical transmission

## TCP vs UDP
| Feature | TCP | UDP |
|---------|-----|-----|
| Reliability | ✓ guaranteed | ✗ best-effort |
| Order | ✓ ordered | ✗ unordered |
| Speed | slower | faster |
| Use case | HTTP, SSH | video, DNS |

## Key Concepts
- **IP address**: Unique network identifier (192.168.1.1)
- **Port**: Process identifier (HTTP=80, HTTPS=443, SSH=22)
- **3-way handshake**: SYN → SYN-ACK → ACK
- **Subnet mask**: Defines network vs host portion

Note: slugify('TCP/IP') = 'tcpip' — special chars stripped.
