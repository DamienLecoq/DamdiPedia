---
id: docker
label: Docker
category: devops
priority: high
status: learning
last_quiz_score: null
next_review: null
ease_factor: 2.5
interval: 1
createdAt: 2025-01-10T10:00:00Z
updatedAt: 2025-01-10T10:00:00Z
relations:
  - target: kubernetes
    type: depends_on
    weight: 0.9
  - target: linux
    type: uses
    weight: 0.7
resources:
  - type: documentation
    title: Docker Official Docs
    url: https://docs.docker.com
---

## What is Docker?
Docker is a containerization platform that allows packaging applications and their dependencies into isolated containers.

## Key Concepts
- **Image**: Read-only template used to create containers
- **Container**: Running instance of an image
- **Dockerfile**: Script that defines how to build an image
- **Registry**: Storage for Docker images (e.g. Docker Hub)

## Common Commands
- `docker build -t myapp .` — build image from Dockerfile
- `docker run -p 8080:80 myapp` — run container with port mapping
- `docker ps` — list running containers
- `docker compose up` — start multi-container apps

## Why Use Docker?
Eliminates "it works on my machine" problems by packaging the full environment.
