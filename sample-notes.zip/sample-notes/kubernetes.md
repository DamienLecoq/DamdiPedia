---
id: kubernetes
label: Kubernetes
category: devops
priority: high
status: learning
last_quiz_score: null
next_review: null
ease_factor: 2.5
interval: 1
createdAt: 2025-01-11T10:00:00Z
updatedAt: 2025-01-11T10:00:00Z
relations:
  - target: docker
    type: orchestrates
    weight: 0.9
  - target: linux
    type: uses
    weight: 0.6
resources:
  - type: documentation
    title: Kubernetes Official Docs
    url: https://kubernetes.io/docs
---

## What is Kubernetes?
Kubernetes (K8s) is an open-source container orchestration system that automates deployment, scaling, and management of containerized applications.

## Key Concepts
- **Pod**: Smallest deployable unit — one or more containers
- **Deployment**: Manages a set of identical pods
- **Service**: Exposes pods to network traffic
- **Namespace**: Virtual cluster for resource isolation
- **Node**: A worker machine in the cluster

## Core Commands
- `kubectl get pods` — list running pods
- `kubectl apply -f deployment.yaml` — apply a config file
- `kubectl scale deployment myapp --replicas=3` — scale up

## Architecture
Control plane (API server, scheduler, etcd) manages worker nodes that run the actual workloads.
